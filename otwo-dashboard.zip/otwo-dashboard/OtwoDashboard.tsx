import { useState, type FormEvent } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import "./OtwoDashboard.css";

const portrait = "/zero-two-portrait.png";

const navItems = [
  { icon: "⌂", label: "Início" },
  { icon: "▢", label: "Chat" },
  { icon: "◉", label: "Memórias" },
  { icon: "♡", label: "Personalidade" },
  { icon: "✧", label: "Capacidades" },
  { icon: "◷", label: "Histórico" },
  { icon: "⚙", label: "Configurações" },
];

const capabilities = [
  "Raciocínio e resolução de problemas",
  "Escrita, revisão e explicação de código",
  "Matemática, lógica e análise",
  "Tradução em vários idiomas",
  "Criação de textos, ideias e projetos",
  "Ajuda com estudos e planejamento",
];

export default function OtwoDashboard() {
  const [draft, setDraft] = useState("");
  const [ownerCode, setOwnerCode] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [activeNav, setActiveNav] = useState("Início");
  const { messages, sendMessage, status, stop, error } = useChat({
    transport: new DefaultChatTransport({ api: "/api/chat" }),
  });

  const busy = status === "submitted" || status === "streaming";

  function submitMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = draft.trim();
    if (!text || busy) return;
    // O backend enviado anteriormente lê metadata.name para determinar o modo.
    // Digite o código no painel de configurações; não o grave no código do frontend.
    sendMessage({
      text,
      ...(ownerCode.trim() ? { metadata: { name: ownerCode.trim() } } : {}),
    });
    setDraft("");
    setActiveNav("Chat");
  }

  function quickPrompt(text: string) {
    setDraft(text);
    setActiveNav("Chat");
  }

  return (
    <main className="otwo-shell">
      <header className="otwo-topbar">
        <button className="otwo-brand" onClick={() => setActiveNav("Início")} aria-label="Página inicial">
          <span className="otwo-mark">乙</span>
          <span><strong>0TWO</strong><small>ゼロツー · IA SUPREMA</small></span>
        </button>
        <div className="otwo-tagline"><span>A INTELIGÊNCIA ENCONTRA A IMAGINAÇÃO</span><small>PODER · CRIATIVIDADE · CONEXÃO</small></div>
        <div className="otwo-online"><i /> SISTEMA ONLINE</div>
        <button className="otwo-profile" onClick={() => setShowSettings(true)}>
          <span className="otwo-profile-text"><small>PAINEL DA IA</small><b>Personalizar sistema ♡</b></span>
          <img src={portrait} alt="Retrato anime da 0TWO" />
        </button>
      </header>

      <div className="otwo-layout">
        <aside className="otwo-sidebar">
          <div className="otwo-side-label">MENU PRINCIPAL</div>
          {navItems.map((item) => (
            <button key={item.label} className={`otwo-nav ${activeNav === item.label ? "active" : ""}`} onClick={() => item.label === "Configurações" ? setShowSettings(true) : setActiveNav(item.label)}>
              <span>{item.icon}</span>{item.label}
            </button>
          ))}
          <div className="otwo-sidebar-quote">PENSAMENTO<br /><b>SEM LIMITES.</b><span className="otwo-quote-glyph">乙</span></div>
          <div className="otwo-sidebar-foot"><i /> INTERFACE PRONTA</div>
        </aside>

        <section className="otwo-main">
          <div className="otwo-hero-grid">
            <article className="otwo-hero-image">
              <img src={portrait} alt="Ilustração anime inspirada na 0TWO" />
              <div className="otwo-image-shade" />
              <div className="otwo-hero-caption"><span>PROTOCOLO 0TWO</span><h1>Olá, visitante.</h1><p>Vamos transformar ideias em possibilidades.</p></div>
              <div className="otwo-image-chip">UNIDADE DE IA <b>· 002</b></div>
            </article>

            <article className="otwo-card otwo-intelligence">
              <div className="otwo-card-kicker">◈ SISTEMA DE INTELIGÊNCIA</div>
              <div className="otwo-title-lockup"><span className="otwo-mini-mark">乙</span><div><h2>0TWO</h2><p>IA ADAPTATIVA</p></div></div>
              {[["Raciocínio", "AVANÇADO"], ["Criatividade", "ATIVA"], ["Análise", "PRONTA"], ["Conversação", "ONLINE"]].map(([label, value], i) => (
                <div className="otwo-stat" key={label}><span>{label}</span><b>{value}</b><div className="otwo-stat-track"><i style={{ width: `${[92, 86, 95, 100][i]}%` }} /></div></div>
              ))}
              <div className="otwo-card-note"><span>✦</span><div><b>PRONTA PARA AJUDAR</b><small>Respostas claras. Ideias ousadas.</small></div></div>
            </article>

            <article className="otwo-card otwo-status">
              <div className="otwo-card-heading"><span>✧</span> STATUS DO SISTEMA</div>
              <div className="otwo-status-line"><span>IA</span><b className="green-dot">ATIVA</b></div>
              <div className="otwo-status-line"><span>INTERFACE</span><b>RESPONSIVA</b></div>
              <div className="otwo-status-line"><span>MODELO</span><b>CONFIGURADO NO SERVIDOR</b></div>
              <div className="otwo-status-line"><span>HISTÓRICO</span><b>SESSÃO ATUAL</b></div>
              <button className="otwo-outline-button" onClick={() => setShowSettings(true)}>Abrir configurações ↗</button>
            </article>
          </div>

          <div className="otwo-lower-grid">
            <section className="otwo-card otwo-chat-card">
              <div className="otwo-card-heading"><span>▣</span> TERMINAL DE CONVERSA <em>{busy ? "GERANDO RESPOSTA…" : "PRONTO"}</em></div>
              <div className="otwo-chat-window" aria-live="polite">
                {messages.length === 0 && <div className="otwo-welcome"><div className="otwo-avatar"><img src={portrait} alt="0TWO" /></div><div><b>0TWO <span>● ONLINE</span></b><p>Sou a 0TWO. Envie uma pergunta, peça uma explicação ou comece um projeto.</p><small>SEU PRÓXIMO PASSO COMEÇA AQUI.</small></div></div>}
                {messages.map((message) => {
                  const text = message.parts?.filter((part) => part.type === "text").map((part) => part.text).join("\n") ?? "";
                  if (!text) return null;
                  return <div className={`otwo-message ${message.role === "user" ? "user" : "assistant"}`} key={message.id}><div className="otwo-message-role">{message.role === "user" ? "VOCÊ" : "0TWO"}</div><div className="otwo-message-bubble">{text}</div></div>;
                })}
                {busy && <div className="otwo-typing"><i /><i /><i /> 0TWO ESTÁ PENSANDO</div>}
                {error && <div className="otwo-error">Não foi possível conectar ao chat. Confira a rota /api/chat e a configuração da API.</div>}
              </div>
              <form className="otwo-composer" onSubmit={submitMessage}>
                <input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Escreva sua mensagem para a 0TWO…" aria-label="Mensagem para 0TWO" />
                {busy ? <button type="button" className="otwo-send" onClick={stop}>Parar ■</button> : <button type="submit" className="otwo-send" disabled={!draft.trim()}>Enviar ↗</button>}
              </form>
              <div className="otwo-chat-hint">ENTER PARA ENVIAR <span>·</span> NÃO COMPARTILHE SENHAS OU DADOS SENSÍVEIS</div>
            </section>

            <section className="otwo-card otwo-personality">
              <div className="otwo-card-heading"><span>♡</span> PERSONALIDADE</div>
              <div className="otwo-trait"><i>♥</i><div><b>Confiante</b><small>Direta e segura nas respostas.</small></div></div>
              <div className="otwo-trait"><i>♥</i><div><b>Criativa</b><small>Explora ideias e caminhos novos.</small></div></div>
              <div className="otwo-trait"><i>♥</i><div><b>Analítica</b><small>Divide problemas em etapas.</small></div></div>
              <div className="otwo-trait"><i>♥</i><div><b>Adaptável</b><small>Ajusta o tom ao contexto.</small></div></div>
              <div className="otwo-quote">“Grandes ideias começam com uma pergunta.”<small>— 0TWO / LOG DE SISTEMA</small></div>
            </section>

            <section className="otwo-card otwo-capabilities">
              <div className="otwo-card-heading"><span>ϟ</span> CAPACIDADES</div>
              {capabilities.map((item, index) => <div className="otwo-capability" key={item}><span>{["⌘", "{ }", "∑", "文", "✧", "◈"][index]}</span>{item}</div>)}
              <div className="otwo-card-bottom">FERRAMENTAS DISPONÍVEIS CONFORME A SOLICITAÇÃO</div>
            </section>

            <section className="otwo-card otwo-quick">
              <div className="otwo-card-heading"><span>ϟ</span> COMANDOS RÁPIDOS</div>
              {["Explique um assunto difícil", "Ajude com um código", "Crie uma ideia de anime", "Monte um plano de estudos"].map((prompt, index) => <button className="otwo-quick-button" key={prompt} onClick={() => quickPrompt(prompt)}><span>{["▤", "⌘", "✧", "▦"][index]}</span>{prompt}<b>↗</b></button>)}
              <div className="otwo-quote-card"><img src={portrait} alt="Retrato decorativo da 0TWO" /><div><b>0TWO // SYSTEM</b><p>Modo criativo ativo.<br />Qual é a próxima missão?</p></div></div>
            </section>
          </div>
          <footer className="otwo-footer"><span>乙 0TWO</span><span>INTERFACE IA · V1.0</span><span>DESIGN NEON // ANIME SYSTEM</span><span className="otwo-footer-live"><i /> SISTEMA ATIVO</span></footer>
        </section>
      </div>

      {showSettings && <div className="otwo-modal-backdrop" onClick={() => setShowSettings(false)}><section className="otwo-modal" onClick={(event) => event.stopPropagation()}><button className="otwo-modal-close" onClick={() => setShowSettings(false)} aria-label="Fechar">×</button><div className="otwo-card-kicker">CONFIGURAÇÕES DO SISTEMA</div><h2>Personalizar 0TWO</h2><p>O servidor que você compartilhou verifica <code>metadata.name</code> para selecionar o modo do chat. Digite aqui o código configurado no seu servidor, se necessário.</p><label htmlFor="otwo-owner-code">Código de acesso (opcional)</label><input id="otwo-owner-code" type="password" value={ownerCode} onChange={(event) => setOwnerCode(event.target.value)} placeholder="Digite o código" autoComplete="off" /><small>O código fica apenas nesta sessão do navegador. Não o coloque em arquivos públicos.</small><button className="otwo-send otwo-save" onClick={() => setShowSettings(false)}>Salvar nesta sessão ✓</button></section></div>}
    </main>
  );
}
